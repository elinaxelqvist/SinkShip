﻿namespace Sänka_skepp
{
    public static class Color
    {
        public static readonly string Blue       = "\u001b[2;94;1;44m";
        public static readonly string Red        = "\u001b[2;91;41m";
        public static readonly string Green      = "\u001b[2;92;1;42m";
        public static readonly string GreenFG    = "\u001b[2;92;49m";
        public static readonly string RedFG      = "\u001b[2;91;49m";
        public static readonly string Cursor     = "\u001b[2;93;49m";
        public static readonly string BoatIsHit  = "\u001b[2;92;1;49m";
        public static readonly string MissedBoat = "\u001b[2;91;1;49m";
        public static readonly string MacPink    = "\u001b[38;5;213m"; //Windowskonsolen har bara 16 färger till skillnad från MacOS och så gott som alla Linux-distron som stödjer många fler, denna färg blir till den vanliga ConsoleColor.Magenta
        public static readonly string Default    = "\u001b[1;97;49m";
    }
}