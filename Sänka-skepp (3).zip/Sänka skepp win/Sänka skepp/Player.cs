﻿using System;

namespace Sänka_skepp
{
    class Player
    {
        Board board;
        string name = "Unnamed";

        Coordinate lastCoordinate = new Coordinate(0,0);

        public Player(Board board)
        {
            this.board = board;

            printName();
            board.Print();
        }
        public Player(string name, Board board) : this(board)
        {
            this.name = name;
        }

        public void PlaceBoats()
        {
            printName();
            foreach (Size size in new Size[] {BoatList.Carrier, BoatList.Battleship, BoatList.Cruiser, BoatList.Submarine, BoatList.Destroyer})
            {
                AddBoat(placeBoat(new Boat(new Coordinate(0,0), size)));
            }
            board.HideTiles(true);
            board.Print();
        }

        public void AddBoat(IBoat boat) => board.AddBoat(boat);

        public bool Shoot() => board.ShootAtTarget(moveCursor());

        public void SwapBoardsWith(Player other)
        {
            Tile[,] temp = this.board.GetTiles();
            this.board.SetTiles(other.board.GetTiles());
            other.board.SetTiles(temp);
        }

        public string GetName() => this.name;

        private IBoat placeBoat(IBoat boat)
        {
            ConsoleKey input;
            Coordinate coord = lastCoordinate;
            do
            {
                Coordinate oldCoords = new Coordinate(coord.GetX(), coord.GetY());

                int cursorX = board.NormalizeToPrintableCoordinate(coord).GetX();
                int cursorY = board.NormalizeToPrintableCoordinate(coord).GetY();

                Console.SetCursorPosition(cursorX, cursorY);


                board.Print();
                board.ShowBoatFootprint(new Boat(coord, boat.GetSize()));
                Console.SetCursorPosition(cursorX, cursorY);


                input = Console.ReadKey().Key;

                coord.AddX(input switch { ConsoleKey.LeftArrow => -1, ConsoleKey.RightArrow => 1, _ => 0 });
                if (coord.GetX() + boat.GetSizeX() > board.GetSize().GetX())
                    coord.AddX(-1);
                coord.AddY(input switch { ConsoleKey.UpArrow => -1, ConsoleKey.DownArrow => 1, _ => 0 });
                if (coord.GetY() + boat.GetSizeY() > board.GetSize().GetY())
                    coord.AddY(-1);


                switch (input)
                {
                    case ConsoleKey.Spacebar:
                        boat.GetSize().SwapXY();

                        int rightMostPartOfBoat = coord.GetX() + boat.GetSizeX();
                        int leftMostPartOfBoat = coord.GetY() + boat.GetSizeY();


                        if (rightMostPartOfBoat > board.GetSize().GetX()) coord.AddX(-rightMostPartOfBoat + board.GetSize().GetX());
                        if (leftMostPartOfBoat > board.GetSize().GetY()) coord.AddY(-leftMostPartOfBoat + board.GetSize().GetY());

                        break;
                    default: break;
                }


            } while (input != ConsoleKey.Enter || !board.CanBoatBePlacedHere(new Boat(coord, boat.GetSize())));
            lastCoordinate = coord;
            return new Boat(coord, boat.GetSize());
        }

        private Coordinate moveCursor()
        {
            Coordinate coord = lastCoordinate;
            board.PrintCursor(board.NormalizeToPrintableCoordinate(coord));


            ConsoleKey input;
            do
            {
                coord = lastCoordinate;
                Coordinate oldCoords = new Coordinate(coord.GetX(), coord.GetY());

                int cursorX = board.NormalizeToPrintableCoordinate(coord).GetX();
                int cursorY = board.NormalizeToPrintableCoordinate(coord).GetY();

                Console.SetCursorPosition(cursorX, cursorY);

                input = Console.ReadKey().Key;

                coord.AddX(input switch { ConsoleKey.LeftArrow => -1, ConsoleKey.RightArrow => 1, _ => 0 });
                if (coord.GetX() > board.GetSize().GetX() - 1)
                    coord.AddX(-1);
                coord.AddY(input switch { ConsoleKey.UpArrow => -1, ConsoleKey.DownArrow => 1, _ => 0 });
                if (coord.GetY() > board.GetSize().GetY() - 1)
                    coord.AddY(-1);

                board.PrintTile(board.NormalizeToPrintableCoordinate(oldCoords));
                board.PrintCursor(board.NormalizeToPrintableCoordinate(coord));
            } while (input != ConsoleKey.Enter);
            lastCoordinate = coord;
            return new Coordinate(coord.GetX(), coord.GetY());
        }

        private void printName()
        {
            double width = board.NormalizeToGrid(board.GetCoord()).GetX() + board.GetSize().GetX();
            int avgWidth = Convert.ToInt32(width / 2);
            int nameMidWay = this.name.Length / 2;

            Console.SetCursorPosition(board.GetCoord().GetX() + avgWidth - nameMidWay, board.GetCoord().GetY() - 1);
            Console.Write(Color.GreenFG + this.name);
        }
    }
}
