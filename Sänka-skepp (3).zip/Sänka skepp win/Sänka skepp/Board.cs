﻿using System;
using System.Collections.Generic;
namespace Sänka_skepp
{
    class Board
    {
        Coordinate coordinate;
        Size size;

        Tile[,] tiles;
        List<IBoat> boats = new List<IBoat>();

        public Board(Size size)
        {
            this.size = size;
            tiles = new Tile[this.size.GetX(), this.size.GetY()];
            fillTiles();
        }

        public Board(Coordinate coordinate, Size size) : this(size)
        {
            this.coordinate = coordinate;
        }

        private void fillTiles()
        {
            for (int y = 0; y < size.GetY(); y++)
            {
                for (int x = 0; x < size.GetX(); x++)
                {
                    tiles[x, y] = new Tile('X', Color.Blue);
                }
            }
        }

        public void AddBoat(IBoat boat)
        {
            boats.Add(boat);

            for (int y = 0; y < boat.GetSizeY(); y++)
            {
                for (int x = 0; x < boat.GetSizeX(); x++)
                {
                    tiles[boat.GetCoordX() + x, boat.GetCoordY() + y].SetStatus(true, false);
                }
            }

            Print();
        }

        public bool ShootAtTarget(Coordinate target)
        {

            tiles[target.GetX(), target.GetY()].ShootAtTile();

            PrintTile(NormalizeToPrintableCoordinate(target));

            return AnyBoatsLeft();
     
        }

        public void ShowBoatFootprint(IBoat boat)
        {
            Coordinate coord = NormalizeToPrintableCoordinate(boat.GetCoordinate());
            Coordinate local = boat.GetCoordinate();

            IntPair endOfBoat = coord + boat.GetSize();

            for (int y = coord.GetY(); y < endOfBoat.GetY(); y++)
            {
                for (int x = coord.GetX(); x < endOfBoat.GetX(); x++)
                {
                    Console.SetCursorPosition(x, y);
                    Coordinate tempCoords = NormalizeToGrid(new Coordinate(x, y));


                    Console.Write((tiles[tempCoords.GetX(), tempCoords.GetY()].HoldsBoat() ? Color.Red : Color.Green) + tiles[local.GetX(), local.GetY()].GetSymbol());
                }
            }
        }
        public bool CanBoatBePlacedHere(IBoat boat)
        {
            Coordinate[,] collection = makeCoordCollection(boat.GetCoordinate(), boat.GetCoordinate() + boat.GetSize());

            foreach(Coordinate coord in collection)
            {
                if (tiles[coord.GetX(), coord.GetY()].HoldsBoat())
                {
                    Console.SetCursorPosition(0, 7);
                    Console.Write(Color.RedFG + "This space is occupied");
                    return false;
                }
            }

            Console.SetCursorPosition(0, 7);
            Console.Write(Color.Default + "                      ");

            return true;
        }

        private Coordinate[,] makeCoordCollection(Coordinate topLeft, Coordinate botRight)
        {
            if(topLeft > botRight)
            {
                Coordinate temp = topLeft;
                topLeft = botRight;
                botRight = temp;
            }
            Coordinate[,] res = new Coordinate[botRight.GetX() - topLeft.GetX(), botRight.GetY() - topLeft.GetY()];

            for (int y = topLeft.GetY(); y < botRight.GetY(); y++)
            {
                for (int x = topLeft.GetX(); x < botRight.GetX(); x++)
                {
                    res[x - topLeft.GetX(), y - topLeft.GetY()] = new Coordinate(x, y);
                }
            }
            return res;
        }

        public void Print()
        {
            for (int y = 0; y < size.GetY(); y++)
            {
                string buffer = "";
                for (int x = 0; x < size.GetX(); x++)
                {
                    if (!tiles[x, y].IsHidden())
                        buffer += tiles[x, y].GetSymbolWithColor();
                    else
                        buffer += Color.Blue + tiles[x, y].GetSymbol();
                }
                Console.SetCursorPosition(coordinate.GetX(), coordinate.GetY() + y);
                Console.Write(buffer);
            }
        }

        public void HideTiles(bool hidden)
        {
            foreach(Tile tile in tiles)
            {
                tile.Hide(hidden);
            }
        }

        public void PrintTile(Coordinate xy)
        {
            Coordinate index = NormalizeToGrid(xy);
            int tileIndexX = index.GetX();
            int tileIndexY = index.GetY();
            Console.SetCursorPosition(xy.GetX(), xy.GetY());
            Console.Write(tiles[tileIndexX, tileIndexY].ToString());
        }
        public void PrintCursor(Coordinate xy)
        {
            Coordinate index = NormalizeToGrid(xy);
            int tileIndexX = index.GetX();
            int tileIndexY = index.GetY();
            Console.SetCursorPosition(xy.GetX(), xy.GetY());
            Console.Write(Color.Cursor + tiles[tileIndexX, tileIndexY].GetSymbol());
        }

        public bool AnyBoatsLeft()
        {
            foreach(Tile t in tiles) if (t.HoldsBoat()) return true;

            return false;
        }

        public Coordinate NormalizeToGrid(Coordinate coord) => coord - coordinate;
        public Coordinate NormalizeToPrintableCoordinate(Coordinate coord) => coord + coordinate;


        public Coordinate GetCoord() => this.coordinate;
        public Size GetSize() => this.size;
        public Tile[,] GetTiles() => this.tiles;
        public void SetTiles(Tile[,] t) => this.tiles = t;

    }
}
