﻿namespace Sänka_skepp
{
    class BoatList
    {
        public static readonly Size Carrier     = new Size(1, 5);
        public static readonly Size Battleship  = new Size(1, 4);
        public static readonly Size Cruiser     = new Size(1, 3);
        public static readonly Size Submarine   = new Size(1, 3);
        public static readonly Size Destroyer   = new Size(1, 2);
    }
}
