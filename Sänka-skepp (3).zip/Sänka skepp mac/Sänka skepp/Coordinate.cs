﻿namespace Sänka_skepp
{
    class Coordinate : IntPair
    {
        public Coordinate(int x, int y)
        {

            this.x = constrain(x);
            this.y = constrain(y);
        }

        public override void AddX(int x) => this.x = constrain(this.x += x);
        public override void AddY(int y) => this.y = constrain(this.y += y);
        private int constrain(int i) => i < 0 ? 0 : i;

        static public Coordinate operator +(Coordinate one, IntPair two) => new Coordinate(one.GetX() + two.GetX(), one.GetY() + two.GetY());
        static public Coordinate operator -(Coordinate one, IntPair two) => new Coordinate(one.GetX() - two.GetX(), one.GetY() - two.GetY());

    }
}
