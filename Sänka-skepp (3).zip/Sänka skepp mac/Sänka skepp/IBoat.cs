﻿namespace Sänka_skepp
{
    interface IBoat
    {
        int GetCoordX();
        int GetCoordY();
        Size GetSize();
        Tile[,] GetTiles();
        int GetSizeX();
        int GetSizeY();
        Coordinate GetCoordinate();
    }
}
