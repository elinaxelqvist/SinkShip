﻿namespace Sänka_skepp
{
    class Tile
    {
        char symbol;
        string color;
        bool holdsBoat = false;
        bool hidden = false;

        public Tile(char symbol, string color)
        {
            this.symbol = symbol;
            this.color = color;
        }

        public bool HoldsBoat() => holdsBoat;
        public bool IsHidden() => hidden;
        public void Hide(bool hidden) => this.hidden = hidden;

        public void SetColor(string color) => this.color = color;
        public void SetStatus(bool holdsBoat, bool isHidden)
        {
            this.holdsBoat = holdsBoat;
            SetColor(holdsBoat ? Color.Green : Color.Red);

            Hide(isHidden);
            if (isHidden) SetColor(Color.Blue);
            else if (holdsBoat) SetColor(Color.Green);
            else SetColor(Color.BoatIsHit);
        }
        private void setStatus(bool hidden) => this.hidden = hidden;

        public void ShootAtTile()
        {
            if (holdsBoat) SetStatus(false, false);
            else
            {
                setStatus(false);
                SetColor(Color.MissedBoat);
            }
        }

        public char GetSymbol() => symbol;
        public string GetSymbolWithColor() => color + symbol;
        public override string ToString() => (IsHidden() ? Color.Blue : color) + symbol + "\x1b[39;49m";
    }
}
