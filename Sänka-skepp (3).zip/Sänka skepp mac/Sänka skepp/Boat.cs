﻿
namespace Sänka_skepp
{
    class Boat : IBoat
    {
        Coordinate coord;
        Size size;
        Tile[,] tiles;

        public Boat(Coordinate coord, Size size)
        {
            this.coord = coord;
            this.size = size;
            this.tiles = new Tile[this.size.GetX(), this.size.GetY()];
            fillTiles();
        }

        public Boat(Size size) => this.size = size;

        private void fillTiles()
        {
            for (int y = 0; y < size.GetY(); y++)
            {
                for (int x = 0; x < size.GetX(); x++)
                {
                    tiles[x, y] = new Tile('X', Color.Green);
                }
            }
        }

        public int GetCoordX() => coord.GetX();
        public int GetCoordY() => coord.GetY();
        public Size GetSize() => this.size;
        public Tile[,] GetTiles() => this.tiles;
        public int GetSizeX() => size.GetX();
        public int GetSizeY() => size.GetY();
        public Coordinate GetCoordinate() => coord;

    }
}
