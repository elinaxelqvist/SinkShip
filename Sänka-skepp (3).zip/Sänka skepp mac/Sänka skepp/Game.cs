﻿using System;
namespace Sänka_skepp
{
    class Game
    {
        Player[] players;
        Size boardSize = new Size(14, 14);
        Size windowSize = new Size(120, 30);
        Coordinate[] playerCoords;

        static bool gameStatus = true;

        public Game()
        {
            run();
        }

        private void run()
        {
            welcome();
            init();
            update();
        }

        private void welcome()
        {
            
            Console.WriteLine(Color.GreenFG + $"Welcome to Battleship!");
            Console.WriteLine(Color.GreenFG + $"Decide which player who will place out their ships first. Place out the first players ships while the other player looks away. Rotate with {Color.MacPink}SPACE{Color.GreenFG} and place them with {Color.MacPink}ENTER{Color.GreenFG}. The other player will do the same. The boats will be hidden when this is done. You can now shoot with {Color.MacPink}ENTER{Color.GreenFG} at the other players boats on your game board. The mission of the game is to shoot down all of the other players boats.\n{Color.Cursor}Press any key to continue...");
            Console.ReadKey();
            Console.Clear();
        }

        private void update()
        {
            while(gameStatus)
            {
                foreach(Player p in players)
                {
                    gameStatus = p.Shoot();
                    if (!gameStatus) endScreen(p);
                }
            }
        }


        private void init()
        {
            int mid = (windowSize.GetX() / 2);
            int padding = 10;
            int height = 5;
            playerCoords = new Coordinate[] { new Coordinate(mid - padding - boardSize.GetX(), height), new Coordinate(mid + padding, height) };
            makePlayers();

            foreach (Player p in players)
               p.PlaceBoats();

            players[0].SwapBoardsWith(players[1]);

        }

        private void makePlayers()
        {
            players = new Player[] { new Player("Player 1", new Board(playerCoords[0], boardSize)), new Player("Player 2", new Board(playerCoords[1], boardSize)) };
        }

        private void endScreen(Player p)
        {
            int x = 42;
            int y = 7;
            Console.SetCursorPosition(x, y++);
            Console.Write(Color.GreenFG + "===================================");
            Console.SetCursorPosition(x, y++);
            Console.Write(Color.GreenFG + $"|         {Color.RedFG}{p.GetName()} Vinner!{Color.GreenFG}        |");
            Console.SetCursorPosition(x, y++);
            Console.Write(Color.GreenFG + "===================================");

            Console.SetCursorPosition(0, 25);

            Environment.Exit(0);
        }
    }
}
