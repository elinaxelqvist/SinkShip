﻿using System;

namespace Sänka_skepp
{
    class Program
    {
        static void Main()
        {
            try
            {
                new Game();
            }
            catch (Exception e)
            {
                Console.WriteLine(Color.RedFG + "Oops! Game ended unexpectedly: " + e.Message + ". Exiting...");
            }
        }
    }
}