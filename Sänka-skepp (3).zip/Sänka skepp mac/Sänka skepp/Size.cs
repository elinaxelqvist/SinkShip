﻿namespace Sänka_skepp
{
    class Size : IntPair
    {
        public Size(int width, int height)
        {
            this.x = width;
            this.y = height;
        }

        public override void AddX(int width) => this.x += width;
        public override void AddY(int height) => this.y += height;
        public override IntPair GetPair() => this;


        static public Size operator +(Size one, IntPair two) => new Size(one.GetX() + two.GetX(), one.GetY() + two.GetY());
        static public Size operator -(Size one, IntPair two) => new Size(one.GetX() - two.GetX(), one.GetY() - two.GetY());
    }
}
