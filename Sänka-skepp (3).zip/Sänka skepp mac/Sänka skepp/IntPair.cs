﻿namespace Sänka_skepp
{
    abstract class IntPair
    {
        protected int x { get; set; }
        protected int y { get; set; }
        public int GetX() => this.x;
        public int GetY() => this.y;
        public virtual void AddX(int x) { }
        public virtual void AddY(int y) { }
        public void SwapXY()
        {
            int temp = x;
            x = y;
            y = temp;
        }

        public virtual IntPair GetPair() => this;

        public override string ToString() => $"({x} , {y})";


        static public bool operator >(IntPair one, IntPair two) => one.GetX() > two.GetX() && one.GetY() > two.GetY();
        static public bool operator <(IntPair one, IntPair two) => one.GetX() < two.GetX() && one.GetY() < two.GetY();
        static public bool operator ==(IntPair one, IntPair two) => one.GetX() == two.GetX() && one.GetY() == two.GetY();
        static public bool operator !=(IntPair one, IntPair two) => one.GetX() != two.GetX() || one.GetY() != two.GetY();

        public override bool Equals(object obj) => base.Equals(obj);
        public override int GetHashCode() => base.GetHashCode();
    }
}
